#ifndef __K9S1208_H__
#define __K9S1208_H__

void K9S1208_Menu(void);

#endif //__K9S1208_H__

