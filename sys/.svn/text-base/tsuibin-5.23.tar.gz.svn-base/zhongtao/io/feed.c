#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
int main()
{
	int i, fd[2];
	srand(time(NULL));
	fd[0] = open("f0", O_WRONLY);
	fd[1] = open("f1", O_WRONLY);
	for (;;) {
		i = rand()%2;
		char c = '0' + i;
		write(fd[i], &c, 1);
		write(1, &c, 1);
		sleep(1);
	}
	return 0;
}
