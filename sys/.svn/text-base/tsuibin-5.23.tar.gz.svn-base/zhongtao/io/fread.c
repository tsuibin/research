#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>
void read_fifo(int fd)
{
	char c;
	while (read(fd, &c, 1)>0) write(1, &c, 1);
	exit(0);
}
int main()
{
	int fd[2];
	fd[0] = open("f0", O_RDONLY);
	fd[1] = open("f1", O_RDONLY);
	if ((fork())==0) read_fifo(fd[0]);
	if ((fork())==0) read_fifo(fd[1]);
	wait(NULL);
	wait(NULL);
	return 0;
}
