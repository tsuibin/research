#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/select.h>
int main()
{
	char c;
	int max_fd, fd[2];
	fd_set watch, read_ready;
	fd[0] = open("f0", O_RDONLY);
	fd[1] = open("f1", O_RDONLY);
	FD_ZERO(&watch);
	FD_SET(fd[0], &watch);
	FD_SET(fd[1], &watch);
	max_fd = fd[0] > fd[1] ? fd[0] : fd[1];
	for (;;) {
		read_ready = watch;
		select(max_fd+1, &read_ready, NULL, NULL, NULL);
		if (FD_ISSET(fd[0], &read_ready)) {
			read(fd[0], &c, 1);
			write(1, &c, 1);
		}
		if (FD_ISSET(fd[1], &read_ready)) {
			read(fd[1], &c, 1);
			write(1, &c, 1);
		}
	}
	return 0;
}
