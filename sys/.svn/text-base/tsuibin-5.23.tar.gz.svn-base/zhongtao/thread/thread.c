#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#define N 10
int n = 100;
pthread_mutex_t mutex;
void *thread(void *arg)
{
	register int AX;
	int a = *((int*)arg);
//	n--;
	pthread_mutex_lock(&mutex);
	AX = n; // move AX, n
	AX--;   // dec AX
	sleep(1);
	n = AX; // move n, AX
	printf("%d %d\n", a, n);
	pthread_mutex_unlock(&mutex);
	return NULL;
}
int main()
{
	int i, a[N];
	pthread_t tid[N];
	for (i=0; i<N; i++) a[i] = i;
	pthread_mutex_init(&mutex, NULL);
	for (i=0; i<N; i++)
		pthread_create(&tid[i], NULL, thread, (void*)&i);
		pthread_create(&tid[i], NULL, thread, (void*)&a[i]);
	for (i=0; i<N; i++)
		pthread_join(tid[i], NULL);
	return 0;
}
