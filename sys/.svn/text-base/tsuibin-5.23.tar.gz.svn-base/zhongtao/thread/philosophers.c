#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#define N 5
#define L(p) (p)
#define R(p) (((p)+1)%N)
pthread_mutex_t chopstick[N];
void pick_up(int me)
{
	if (me==0) {
		pthread_mutex_lock(&chopstick[L(me)]);
		pthread_mutex_lock(&chopstick[R(me)]);
	} else {
		pthread_mutex_lock(&chopstick[R(me)]);
		pthread_mutex_lock(&chopstick[L(me)]);
	}
}
void put_down(int me)
{
	pthread_mutex_unlock(&chopstick[L(me)]);
	pthread_mutex_unlock(&chopstick[R(me)]);
}
void *philosopher(void *arg)
{
	int me = *((int*)arg);
	for (;;) {
		pick_up(me);
		printf("%d eating...\n", me);
		sleep(1);
		put_down(me);
		printf("%d thinking...\n", me);
		sleep(1);
	}
	return NULL;
}
int main()
{
	pthread_t tid[N];
	int i, a[N];
	for (i=0; i<N; i++) a[i] = i;
	for (i=0; i<N; i++) 
		pthread_mutex_init(&chopstick[i], NULL);
	for (i=0; i<N; i++)
		pthread_create(&tid[i], NULL, philosopher, (void*)&a[i]);
	for (i=0; i<N; i++)
		pthread_join(tid[i], NULL);
	return 0;
}
